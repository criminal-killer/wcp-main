<?php
require_once 'config.php';
// Basic thank you page as a fallback or static display if needed
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>🎉 You're on the list! — Sella</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 20px; }
        .thank-you-card { max-width: 500px; text-align: center; }
    </style>
</head>
<body>
    <div class="form-container thank-you-card">
        <h1>🎉 You're In!</h1>
        <p>Thanks for joining the SELLA waitlist. We'll be in touch soon.</p>
        <br>
        <a href="index.html" class="btn btn-primary">Back to Homepage</a>
    </div>
</body>
</html>
