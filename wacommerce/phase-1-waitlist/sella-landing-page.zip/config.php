<?php
// Database configuration for InfinityFree MySQL
// Replace these with your actual InfinityFree MySQL details
$db_host = 'sql123.infinityfree.com'; 
$db_name = 'if0_38000000_sella';     
$db_user = 'if0_38000000';           
$db_pass = 'your_password';          

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Fail silently in production or log to file
    error_log("Database connection failed: " . $e->getMessage());
    // die("Connection failed"); // Comment out for production
}

// App config
$app_name = "Sella";
$app_url = "https://sella.io"; // Change to your InfinityFree URL
$admin_password = "admin-sella-2025!"; // Change this!

// Session for admin
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
